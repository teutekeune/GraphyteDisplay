#include <Graphyte.h>

// ---- I2C config - must match the slave sketch -------------------------
#define I2C_SDA        21
#define I2C_SCL        20
#define I2C_SLAVE_ADDR 0x08
#define I2C_FREQ       100000

// How long each drawn frame stays on screen before moving to the next step
#define STEP_DELAY_MS  180

GraphyteDisplay gfx(I2C_SLAVE_ADDR);

void logResult(const char *label) {
  Serial.print("  ");
  Serial.print(label);
  Serial.print(" -> ");
  Serial.println(GraphyteDisplay::errorString(gfx.lastError()));
}

void step(const char *label) {
  Serial.println(label);
}

void setup() {
  Serial.begin(115200);
  delay(300);

  Serial.println("Graphyte I2C test master ready.");
  Serial.print("Probing slave at 0x");
  Serial.println(I2C_SLAVE_ADDR, HEX);

  if (gfx.begin(I2C_SDA, I2C_SCL, I2C_FREQ)) {
    Serial.println("Slave found, starting test loop.");
  } else {
    Serial.println("WARNING: slave did not ACK. Check SDA/SCL wiring, "
                    "shared ground, pull-up resistors, and that the "
                    "slave sketch is running.");
  }
}

void loop() {
  step("CLEAR");
  gfx.clear();
  logResult("clear");
  delay(STEP_DELAY_MS);

  step("DRAW_LINE - X across the whole screen");
  gfx.drawLine(0, 0, 79, 15);
  logResult("drawLine");
  gfx.drawLine(79, 0, 0, 15);
  logResult("drawLine");
  delay(STEP_DELAY_MS);

  step("CLEAR");
  gfx.clear();
  logResult("clear");
  delay(400);

  step("DRAW_RECT - outline");
  gfx.drawRect(5, 2, 25, 10);
  logResult("drawRect");
  delay(STEP_DELAY_MS);

  step("INVERT_RECT - same outline, toggles it off");
  gfx.invertRect(5, 2, 25, 10);
  logResult("invertRect");
  delay(STEP_DELAY_MS);

  step("CLEAR");
  gfx.clear();
  logResult("clear");
  delay(400);

  step("DRAW_RECT_FILLED");
  gfx.drawRectFilled(5, 2, 30, 12);
  logResult("drawRectFilled");
  delay(STEP_DELAY_MS);

  step("INVERT_RECT_FILLED - punches a hole in it");
  gfx.invertRectFilled(15, 5, 12, 6);
  logResult("invertRectFilled");
  delay(STEP_DELAY_MS);

  step("CLEAR");
  gfx.clear();
  logResult("clear");
  delay(400);

  step("DRAW_CIRCLE - outline");
  gfx.drawCircle(40, 8, 7);
  logResult("drawCircle");
  delay(STEP_DELAY_MS);

  step("INVERT_CIRCLE - same circle, toggles it off");
  gfx.invertCircle(40, 8, 7);
  logResult("invertCircle");
  delay(STEP_DELAY_MS);

  step("CLEAR");
  gfx.clear();
  logResult("clear");
  delay(400);

  step("DRAW_CIRCLE_FILLED");
  gfx.drawCircleFilled(40, 8, 7);
  logResult("drawCircleFilled");
  delay(STEP_DELAY_MS);

  step("INVERT_CIRCLE_FILLED - punches a hole in the center");
  gfx.invertCircleFilled(40, 8, 3);
  logResult("invertCircleFilled");
  delay(STEP_DELAY_MS);

  step("CLEAR");
  gfx.clear();
  logResult("clear");
  delay(400);

  step("DRAW_TEXT");
  gfx.drawText(2, 4, "HELLO I2C");
  logResult("drawText");
  delay(STEP_DELAY_MS * 2);

  step("CLEAR - restarting cycle");
  gfx.clear();
  logResult("clear");
  delay(1000);
}
