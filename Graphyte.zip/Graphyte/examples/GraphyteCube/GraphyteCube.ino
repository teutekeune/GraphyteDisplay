/*
  GraphyteCube - spinning wireframe cube over I2C.

  Unlike a bit-banged HD44780 custom-character demo, the Graphyte
  slave already knows how to draw lines on its own display. So all
  this sketch has to do each frame is:
    1. Rotate the cube's 8 vertices.
    2. Project them from 3D down to 2D screen coordinates.
    3. Ask the slave to clear the screen and draw the 12 edges.

  No local framebuffer, no tile packing, no dual-core task juggling -
  the Graphyte class + I2C link do the heavy lifting on the slave side.
*/

#include <Graphyte.h>
#include <math.h>

// ---- I2C config - must match the slave sketch -------------------------
#define I2C_SDA        21
#define I2C_SCL        20
#define I2C_SLAVE_ADDR 0x08
#define I2C_FREQ       100000

// Must match the slave's actual screen resolution.
#define SCREEN_W 80
#define SCREEN_H 16

#define FRAME_DELAY_MS 40   // ~25 fps
#define SPIN_SPEED     0.08f

GraphyteDisplay gfx(I2C_SLAVE_ADDR);

// ===== 3D CUBE DATA =====

typedef struct {
  float x;
  float y;
  float z;
} Vec3;

float cubeAngle = 0;

Vec3 cubeVerts[8] = {
  {-1,-1,-1},
  { 1,-1,-1},
  { 1, 1,-1},
  {-1, 1,-1},
  {-1,-1, 1},
  { 1,-1, 1},
  { 1, 1, 1},
  {-1, 1, 1}
};

int cubeEdges[12][2] = {
  {0,1},{1,2},{2,3},{3,0},
  {4,5},{5,6},{6,7},{7,4},
  {0,4},{1,5},{2,6},{3,7}
};

// Clamp a projected float coordinate into a valid on-screen uint8_t.
// (The link only carries uint8_t, so anything off-screen needs to be
// clipped here rather than letting it silently wrap around.)
inline uint8_t clampCoord(float v, uint8_t maxVal) {
  if (v < 0) v = 0;
  if (v > (float)maxVal) v = (float)maxVal;
  return (uint8_t)(v + 0.5f);
}

// Rotate + project the cube, then send the 12 edges to the display.
void drawCube(float angle) {
  Vec3 rotated[8];

  float s = sin(angle);
  float c = cos(angle);

  float s2 = sin(angle * 0.7f);
  float c2 = cos(angle * 0.7f);

  for (int i = 0; i < 8; i++) {
    float x = cubeVerts[i].x;
    float y = cubeVerts[i].y;
    float z = cubeVerts[i].z;

    // rotate around Y
    float x1 = x * c - z * s;
    float z1 = x * s + z * c;

    // rotate around X
    float y1 = y * c2 - z1 * s2;
    float z2 = y * s2 + z1 * c2;

    rotated[i] = {x1, y1, z2};
  }

  uint8_t px[8];
  uint8_t py[8];

  float scale = 4;

  for (int i = 0; i < 8; i++) {
    float z = rotated[i].z + 4; // push the cube away from the camera

    float sx = (SCREEN_W / 2.0f) + rotated[i].x * scale / z * 10.0f;
    float sy = (SCREEN_H / 2.0f) + rotated[i].y * scale / z * 10.0f;

    px[i] = clampCoord(sx, SCREEN_W - 1);
    py[i] = clampCoord(sy, SCREEN_H - 1);
  }

  for (int i = 0; i < 12; i++) {
    int a = cubeEdges[i][0];
    int b = cubeEdges[i][1];
    gfx.drawLine(px[a], py[a], px[b], py[b]);
  }
}

void setup() {
  Serial.begin(115200);
  delay(300);

  Serial.println("Graphyte spinning cube demo.");
  Serial.print("Probing slave at 0x");
  Serial.println(I2C_SLAVE_ADDR, HEX);

  if (gfx.begin(I2C_SDA, I2C_SCL, I2C_FREQ)) {
    Serial.println("Slave found, starting cube.");
  } else {
    Serial.println("WARNING: slave did not ACK. Check SDA/SCL wiring, "
                    "shared ground, pull-up resistors, and that the "
                    "slave sketch is running.");
  }
}

void loop() {
  gfx.clear();
  cubeAngle += SPIN_SPEED;
  drawCube(cubeAngle);
  delay(FRAME_DELAY_MS);
}
