/*
  Graphyte.h - Arduino library for controlling a Graphyte-protocol
  I2C display slave (clear / lines / rects / circles / text).

  This library is a thin, buffered wrapper around the raw I2C
  command protocol: it just packs each drawing call into the
  right byte sequence and sends it with Wire.

  Usage:
    #include <Graphyte.h>

    GraphyteDisplay gfx; // default address 0x08, uses the global Wire

    void setup() {
      Serial.begin(115200);
      gfx.begin(21, 20, 100000); // SDA, SCL, freq (ESP32-style); on
                                  // boards with fixed I2C pins you can
                                  // just call gfx.begin();
    }

    void loop() {
      gfx.clear();
      gfx.drawRect(5, 2, 25, 10);
      gfx.drawText(2, 4, "HELLO");
    }
*/

#ifndef GRAPHYTE_H
#define GRAPHYTE_H

#include <Arduino.h>
#include <Wire.h>

// Default 7-bit I2C address of the Graphyte slave.
#define GRAPHYTE_DEFAULT_ADDR 0x08

// Error codes mirror what Wire.endTransmission() returns.
#define GRAPHYTE_ERR_OK         0
#define GRAPHYTE_ERR_TOO_LONG   1  // data too long for TX buffer
#define GRAPHYTE_ERR_NACK_ADDR  2  // NACK on address (slave not responding)
#define GRAPHYTE_ERR_NACK_DATA  3  // NACK on data
#define GRAPHYTE_ERR_TIMEOUT    5  // timeout
#define GRAPHYTE_ERR_UNKNOWN    255

class GraphyteDisplay {
  public:
    // addr: 7-bit I2C address of the slave.
    // wire: which TwoWire bus to use (defaults to the global Wire).
    explicit GraphyteDisplay(uint8_t addr = GRAPHYTE_DEFAULT_ADDR, TwoWire &wire = Wire);

    // Initializes the I2C bus.
    // sda/scl: only used on platforms that support Wire.begin(sda, scl, freq)
    //          (e.g. ESP32). Pass -1 (default) to use the board's fixed pins.
    // freq:    I2C clock speed in Hz.
    bool begin(int sda = -1, int scl = -1, uint32_t freq = 100000);

    // Probes the slave address and returns true if it ACKs.
    bool isConnected();

    // Error code from the most recent command (see GRAPHYTE_ERR_* above).
    uint8_t lastError() const;

    // Human-readable string for an error code.
    static const char *errorString(uint8_t err);

    // ---- Drawing commands -------------------------------------------
    void clear();

    void drawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1);
    void invertLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1);

    void drawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h);
    void invertRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h);
    void drawRectFilled(uint8_t x, uint8_t y, uint8_t w, uint8_t h);
    void invertRectFilled(uint8_t x, uint8_t y, uint8_t w, uint8_t h);

    void drawCircle(uint8_t cx, uint8_t cy, uint8_t r);
    void invertCircle(uint8_t cx, uint8_t cy, uint8_t r);
    void drawCircleFilled(uint8_t cx, uint8_t cy, uint8_t r);
    void invertCircleFilled(uint8_t cx, uint8_t cy, uint8_t r);

    void drawText(uint8_t x, uint8_t y, const char *text);
    void drawText(uint8_t x, uint8_t y, const String &text);

  private:
    enum GraphyteOp : uint8_t {
      OP_CLEAR               = 0x00,
      OP_DRAW_LINE            = 0x01,
      OP_INVERT_LINE          = 0x02,
      OP_DRAW_RECT            = 0x03,
      OP_INVERT_RECT          = 0x04,
      OP_DRAW_RECT_FILLED     = 0x05,
      OP_INVERT_RECT_FILLED   = 0x06,
      OP_DRAW_CIRCLE          = 0x07,
      OP_INVERT_CIRCLE        = 0x08,
      OP_DRAW_CIRCLE_FILLED   = 0x09,
      OP_INVERT_CIRCLE_FILLED = 0x0A,
      OP_DRAW_TEXT            = 0x0B,
    };

    TwoWire *_wire;
    uint8_t _addr;
    uint8_t _lastError;

    void sendCmd(uint8_t op);
    void sendCmd3(uint8_t op, uint8_t a, uint8_t b, uint8_t c);
    void sendCmd4(uint8_t op, uint8_t a, uint8_t b, uint8_t c, uint8_t d);
};

#endif // GRAPHYTE_H
