#include "Graphyte.h"

GraphyteDisplay::GraphyteDisplay(uint8_t addr, TwoWire &wire)
  : _wire(&wire), _addr(addr), _lastError(GRAPHYTE_ERR_OK) {
}

bool GraphyteDisplay::begin(int sda, int scl, uint32_t freq) {
#if defined(ARDUINO_ARCH_ESP32)
  if (sda >= 0 && scl >= 0) {
    _wire->begin(sda, scl, freq);
  } else {
    _wire->begin();
    _wire->setClock(freq);
  }
#else
  (void)sda;
  (void)scl;
  _wire->begin();
  _wire->setClock(freq);
#endif
  return isConnected();
}

bool GraphyteDisplay::isConnected() {
  _wire->beginTransmission(_addr);
  _lastError = _wire->endTransmission();
  return _lastError == GRAPHYTE_ERR_OK;
}

uint8_t GraphyteDisplay::lastError() const {
  return _lastError;
}

const char *GraphyteDisplay::errorString(uint8_t err) {
  switch (err) {
    case GRAPHYTE_ERR_OK:        return "OK";
    case GRAPHYTE_ERR_TOO_LONG:  return "data too long for TX buffer";
    case GRAPHYTE_ERR_NACK_ADDR: return "NACK on address (slave not responding - check wiring/power)";
    case GRAPHYTE_ERR_NACK_DATA: return "NACK on data";
    case GRAPHYTE_ERR_TIMEOUT:   return "timeout";
    default:                     return "unknown error";
  }
}

void GraphyteDisplay::sendCmd(uint8_t op) {
  _wire->beginTransmission(_addr);
  _wire->write(op);
  _lastError = _wire->endTransmission();
}

void GraphyteDisplay::sendCmd3(uint8_t op, uint8_t a, uint8_t b, uint8_t c) {
  _wire->beginTransmission(_addr);
  _wire->write(op);
  _wire->write(a);
  _wire->write(b);
  _wire->write(c);
  _lastError = _wire->endTransmission();
}

void GraphyteDisplay::sendCmd4(uint8_t op, uint8_t a, uint8_t b, uint8_t c, uint8_t d) {
  _wire->beginTransmission(_addr);
  _wire->write(op);
  _wire->write(a);
  _wire->write(b);
  _wire->write(c);
  _wire->write(d);
  _lastError = _wire->endTransmission();
}

void GraphyteDisplay::clear() {
  sendCmd(OP_CLEAR);
}

void GraphyteDisplay::drawLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1) {
  sendCmd4(OP_DRAW_LINE, x0, y0, x1, y1);
}

void GraphyteDisplay::invertLine(uint8_t x0, uint8_t y0, uint8_t x1, uint8_t y1) {
  sendCmd4(OP_INVERT_LINE, x0, y0, x1, y1);
}

void GraphyteDisplay::drawRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h) {
  sendCmd4(OP_DRAW_RECT, x, y, w, h);
}

void GraphyteDisplay::invertRect(uint8_t x, uint8_t y, uint8_t w, uint8_t h) {
  sendCmd4(OP_INVERT_RECT, x, y, w, h);
}

void GraphyteDisplay::drawRectFilled(uint8_t x, uint8_t y, uint8_t w, uint8_t h) {
  sendCmd4(OP_DRAW_RECT_FILLED, x, y, w, h);
}

void GraphyteDisplay::invertRectFilled(uint8_t x, uint8_t y, uint8_t w, uint8_t h) {
  sendCmd4(OP_INVERT_RECT_FILLED, x, y, w, h);
}

void GraphyteDisplay::drawCircle(uint8_t cx, uint8_t cy, uint8_t r) {
  sendCmd3(OP_DRAW_CIRCLE, cx, cy, r);
}

void GraphyteDisplay::invertCircle(uint8_t cx, uint8_t cy, uint8_t r) {
  sendCmd3(OP_INVERT_CIRCLE, cx, cy, r);
}

void GraphyteDisplay::drawCircleFilled(uint8_t cx, uint8_t cy, uint8_t r) {
  sendCmd3(OP_DRAW_CIRCLE_FILLED, cx, cy, r);
}

void GraphyteDisplay::invertCircleFilled(uint8_t cx, uint8_t cy, uint8_t r) {
  sendCmd3(OP_INVERT_CIRCLE_FILLED, cx, cy, r);
}

void GraphyteDisplay::drawText(uint8_t x, uint8_t y, const char *text) {
  _wire->beginTransmission(_addr);
  _wire->write(OP_DRAW_TEXT);
  _wire->write(x);
  _wire->write(y);
  for (const char *p = text; *p; p++) {
    _wire->write((uint8_t)*p);
  }
  _lastError = _wire->endTransmission();
}

void GraphyteDisplay::drawText(uint8_t x, uint8_t y, const String &text) {
  drawText(x, y, text.c_str());
}
